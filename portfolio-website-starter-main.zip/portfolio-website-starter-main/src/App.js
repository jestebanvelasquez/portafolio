import React from 'react';

// import components

const App = () => {
  return <div>react app</div>;
};

export default App;
